// src/kz/edu/java46/library/storage/DataStorage.java
package kz.edu.java46.library.storage;

public class DataStorage {
    public void loadAllData() {
    }
    public void saveAllData() {
    }
}