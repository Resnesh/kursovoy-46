package kz.edu.java46.library.service;

public class DataStorage {

    public void saveAllData() {
        System.out.println("LOG: Saving all data to file...");
    }

    public void loadAllData() {
        System.out.println("LOG: Loading all data from file...");
    }
}